title: FaskAPI简单使用
date: '2019-11-18 14:51:25'
updated: '2019-11-22 08:55:45'
tags: [FastApi]
permalink: /articles/2019/11/18/1574059884992.html
---
## <center>FastApi(简介篇)</center>
### 开篇
最近又抽空看了看开源的框架，由于近一年python使用的比较多，所以关注了一下python的web框架情况，其中一款官方称其为“One of the fastest Python frameworks available”的框架比较引人注目，刚看的时候并不是被性能方面的介绍吸引，而是他的集成docs，以下先来看一下框架自动生成的效果。
![index01swaggeruisimple.png](https://img.hacpai.com/file/2019/11/index01swaggeruisimple-aadad1a4.png)
文档页面，集测试、文档功能于一体，还是比较好用的，哈哈。
趁热打铁再来看一下性能方面
![Screenshotfrom20191118155254.png](https://img.hacpai.com/file/2019/11/Screenshotfrom20191118155254-876348af.png)
**fastapi稳居第一**
看一下以往用的非常多的flask、django等都排在了后面。
### FastApi简介
总结来说，就是快、好用、好看
### <span id="fast">快速启动FastApi应用</span>

因为官方对python3.6表现出了很好的亲和力，那么我们在这也会使用python3.6进行构建。
因为我本人用的是Ubuntu18的系统，以下关于应用安装部分，以linux为准。
```
sudo apt-get install python3
```
这里关于python3的安装就不再赘述了，windows直接下载相关安装包即可。
接下来开始安装FastApi的库
```
pip3 install fastapi -i https://pypi.doubanio.com/simple
```
因为大家都知道的网络问题，这里使用豆瓣源进行安装
```
pip3 install uvicorn -i https://pypi.doubanio.com/simple
```
这里安装的uvicorn是一个轻量级高效的web服务器框架，这里就不再陈述了，往后有机会会着重介绍。
安装后了相关库之后，需要创建py文件用来做我们的启动app
```
vim main.py
```
``main.py``内编辑如下内容:
```python
from fastapi import FastAPI
my_app = FastAPI()

@app.get("/")
def read_index():
      return {"Hello":"World"}
```
就此，可以启动一个简单的FastAPI项目了，结构上类似flask
```
uvicorn main:my_app --reload
```
启动后访问``http://127.0.0.1``就可以看到我们返回的json数据了
访问``http://127.0.0.1/docs``即可查看和测试api

### 现代Python类型的简单使用
这里以一小段代码示例，一般都可以看懂了
```python
from pydantic import BaseModel

class Item(BaseModel):
    name: str
    price: float
    is_offer: bool = None

myitem:Item=Item(name="symoon",price=1.0,is_offer=True)
demo={"name":"willson","price":2.0,"is_offer":False}
myitem2:Item=Item(**demo)
print(myitem)
#Item name='symoon' price=1.0 is_offer=True
print(myitem2)
#Item name='willson' price=2.0 is_offer=False
```
好处用多了就能体会了，例如
```python
print("my name is {},my price is {}，offer status is {}".format(myitem.name,myitem.price,myitem.is_offer))
#my name is symoon,my price is 1.0，offer status is True
```
### 现代 Python类型在FastAPI中的应用
现代Python类型在FastAPI应用的重要性，主要在于Docs方面，且在代码整洁度上也有一定的优势。废话不多说，直接上代码
```python
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()


class Item(BaseModel):
    name: str
    price: float
    is_offer: bool = None


@app.get("/")
def read_root():
    return {"Hello": "World"}

@app.put("/items/{item_id}")
def update_item(item_id: int, item: Item):
    return {"item_name": item.name, "item_id": item_id}
```
接口关键字段提取与flask的应用相差不大，Item的使用，可以让Docs看起来更加规范，测试接口的流程更加人性化。
利用这样的方式创建接口，Docs上的表现如下
![Screenshotfrom20191119181248.png](https://img.hacpai.com/file/2019/11/Screenshotfrom20191119181248-1ac4e82c.png)
在接口文档中已经更新了接口类型，包含对象调用参数。Try it out可直接测试。
### Router简单使用

单文件启动后，肯定要开始考虑项目目录结构的问题，接下来要用到的就是router的使用。
简单的介绍就不说了，明确来说就是讲请求分发到各个view的应用形式。
目录结构如下
```linux
└── fast_demo
    ├── __init__.py
    ├── main.py
    └── router
        ├── __init__.py
        ├── items.py
        └── users.py
```
先搞一下items的代码
```python
from fastapi import APIRouter, HTTPException

router = APIRouter()


@router.get("/")
async def read_items():
    return {"msg":"here is items"}
```
再此代码中建立了APIRouter对象，用于路由分发。
接下来是users的代码，与items一样
```python
from fastapi import APIRouter

router = APIRouter()


@router.get("/", tags=["users"])
async def read_users():
    return {"msg":"here is users"}
```
同样创建了APIRouter对象，接下来就为他们创建分发主体。回到我们的main.py，代码如下
```
from fastapi import Depends, FastAPI, Header, HTTPException
from router import items,users
app = FastAPI()

app.include_router(users.router,prefix="/users",tags=["users"])
app.include_router(
    items.router,
    prefix="/items",
    tags=["items"],
    dependencies=[Depends(get_token_header)],
    responses={404: {"description": "Not found"}},
)
```
像[快速启动FastApi应用](#fast)一样，启动
```python
uvicorn main:app --reload
```
访问``http://127.0.0.1/items``
页面返回应该是我们刚才定义的``{"msg":"here is items"}``
访问``http://127.0.0.1/users``
页面返回应该是我们刚才定义的``{"msg":"here is users"}``
访问``http://127.0.0.1/docs``文档页面应该是这样的
![Screenshotfrom20191121171058.png](https://img.hacpai.com/file/2019/11/Screenshotfrom20191121171058-21be7f52.png)
![Screenshotfrom20191121171104.png](https://img.hacpai.com/file/2019/11/Screenshotfrom20191121171104-088144c1.png)
这说明我们的路由分发成功了，具体文件结构就看项目需要了





