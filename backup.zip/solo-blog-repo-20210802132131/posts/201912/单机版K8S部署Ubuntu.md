title: 单机版K8S部署(Ubuntu)
date: '2019-12-18 17:14:19'
updated: '2019-12-18 17:14:19'
tags: [K8S, Docker]
permalink: /articles/2019/12/18/1576660459097.html
---
![](https://img.hacpai.com/bing/20191209.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

### K8S背景
<hr>
其实道理大家都懂哈，基本搞过后端开发，用过docker，用过容器化技术，部署过服务的都接触过K8S，感觉上。哈哈，所以就简单说说。
K8S呢可以说是管理docker-container的车间，通过namespace隔离，可以将一组container组成的业务隔离开来。
同时，最为重要的，就是K8S的资源调度能力，不管是负载均衡啊乱七八糟的东西都非常好用。
废话不多说了，本篇简单说说单机部署的流程。

### 系统准备
<hr>
本人用的是Ubuntu18，以下以此为例。

#### 基础环境

##### docker
这个不用说了吧，K8S专门盘container的，肯定要这个。
##### 关防火墙
```
sudo ufw disable
```
关防火墙这个一般还是需要的，看自己的需求吧。
##### 关闭系统swap
```
sudo swapoff -a
```
这个不关就等着报错吧
#### K8S环境

##### 添加K8s安装密钥
先执行
```
sudo apt update &&  sudo apt install -y apt-transport-https curl
```
然后执行
```
curl -s https://mirrors.aliyun.com/kubernetes/apt/doc/apt-key.gpg |  sudo apt-key add -
```
##### 配置K8S源
```
sudo touch /etc/apt/sources.list.d/kubernetes.list
```
这一步主要是为了安装K8S相关组件配置下载源，因为网络的问题分为两种形式吧。
**如果你VPN挂好了**
```
sudo  echo  "deb http://apt.kubernetes.io/ kubernetes-xenial main"  >> /etc/apt/sources.list.d/kubernetes.list
```
如果你没挂好，就老实用国内的吧。
这里我选择阿里云的
```
sudo  echo  "deb https://mirrors.aliyun.com/kubernetes/apt/ kubernetes-xenial main"  >> /etc/apt/sources.list.d/kubernetes.list
```
种类没选择好的话接下来安装那一步就等着连接超时吧
##### 安装kubeadm及kubelet等工具
正常安装
```
sudo  apt-get update
```
更新完安装
```
sudo  apt-get  install -y kubelet kubeadm kubectl
```
保持版本取消自动更新，这里也可以省略
```
sudo apt-mark hold kubelet kubeadm kubectl
```
#### kubeadm初始化
##### 初始化操作
我这里用了阿里云镜像，用了1.17.0版本，其他版本自行选择吧
```
sudo kubeadm init --image-repository registry.aliyuncs.com/google_containers --kubernetes-version v1.17.0 --pod-network-cidr=10.240.0.0/16
```
等待等待等待好长时间，然后
```
// ...
Your Kubernetes control-plane has initialized successfully!

To start using your cluster, you need to run the following as a regular user:

  mkdir -p $HOME/.kube
  sudo cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
  sudo chown $(id -u):$(id -g) $HOME/.kube/config

You should now deploy a pod network to the cluster.
Run "kubectl apply -f [podnetwork].yaml" with one of the options listed at:
  https://kubernetes.io/docs/concepts/cluster-administration/addons/

Then you can join any number of worker nodes by running the following on each as root:

kubeadm join 机器IP:6443 --token q1guce.z76o2a2bb65vhd0u \
    --discovery-token-ca-cert-hash sha256:2a57a27853c66d608bc544742b57602a21d47c3d09fe58eef15258946d4341c0
```
##### 配置非root的操作
```
mkdir -p $HOME/.kube
```
```
sudo  cp -i /etc/kubernetes/admin.conf $HOME/.kube/config
```
```
sudo  chown  $(id -u):$(id -g)  $HOME/.kube/config
```
##### coredns问题解决
这个时候可以查看pod状态了，K8S已经启动了支持服务，其中有coredns服务可能一直处于pending状态，那么我们需要做如下操作

**执行**
```
kubectl apply -f https://docs.projectcalico.org/v3.10/manifests/calico.yaml

```
这样我们会安装calico网络插件，其实flannel也可以的哈哈。。
这次查看pod状态
```
`kubectl get pods --all-namespaces`
```
效果应该如下

```
NAMESPACE     NAME                                        READY     STATUS    RESTARTS   AGE
kube-system   calico-kube-controllers-74c9747c46-mvlt7    1/1       Running   0          92s
kube-system   calico-node-mmdm7                           1/1       Running   0          93s
kube-system   coredns-9d85f5447-9fx8g                     1/1       Running   0          154m
kube-system   coredns-9d85f5447-zpxhq                     1/1       Running   0          154m
kube-system   etcd-symoon-all-series                      1/1       Running   0          155m
kube-system   kube-apiserver-symoon-all-series            1/1       Running   0          155m
kube-system   kube-controller-manager-symoon-all-series   1/1       Running   0          155m
kube-system   kube-proxy-rdgvk                            1/1       Running   0          154m
kube-system   kube-scheduler-symoon-all-series            1/1       Running   0          155m

```
#### 运行相关
简单说一点点
##### Master隔离解除
```
`kubectl taint nodes --all node-role.kubernetes.io/master-`
```
成功后输出
```
`node/symoon untainted`
```
##### 加入工作节点
这项工作是集群的，单机可以忽略
执行上面init出现的join结果
```
kubeadm join --token <token> <master-ip>:<master-port> --discovery-token-ca-cert-hash sha256:<hash>

# kubeadm token list (可以获取<token>的值)
# kubeadm token create (可以创建<token>新的值)

# --discovery-token-ca-cert-hash (以下命令可以获取 --discovery-token-ca-cert-hash的值)
# openssl x509 -pubkey -in /etc/kubernetes/pki/ca.crt | openssl rsa -pubin -outform der 2>/dev/null | openssl dgst -sha256 -hex | sed 's/^.* //'

```
加成功的话ready-node就会变成两个了
**结束**
