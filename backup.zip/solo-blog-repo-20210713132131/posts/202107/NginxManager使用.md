title: Nginx-Manager使用
date: '2021-07-01 10:46:55'
updated: '2021-07-01 11:10:27'
tags: [Docker, nginx]
permalink: /articles/2021/07/01/1625107615856.html
---
![](https://b3logfile.com/bing/20201222.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

![](https://b3logfile.com/bing/20190820.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 前言

之前都默默的写nginx.conf,现在可以说是后台直接一键配置了。这么好用的工具不能错过。接下来分几步大致讲解使用ngxin-proxy-manager的流程。

## 快速启动

在我的服务器内，基本所有的服务都是使用docker启动的，nginx也不例外，所启动的服务与nginx处于同一个networks下，这样即不用暴露端口，又可以保证服务的正常运行。

docker-compose.yaml:

```yaml
version: '3.7'

services:

  nginx-proxy-manager:
    image: jlesage/nginx-proxy-manager:latest
    container_name: nginx-proxy-manager
    restart: always
    expose:
      - 8181
    ports:
      - 80:8080
      - 443:4443
    environment:
      TZ: Asia/Shanghai
    volumes:
      - ./volumes/nginx-proxy-manager:/config:rw
      - /var/run/docker.sock:/docker.sock:ro

networks:
  default:
    external:
      name: gateway

```

这里有一个点要注意。yaml中写了expose: -8181 这里是直接提供容器内部端口，并且不暴露宿主机端口，但在配置nginx前，宿主机端口还是需要暴露nginx服务的，这里可以在porst加上8181:8181，后续在我们配置好nginx转发后，可以再进行up。

修改后:

```yaml
version: '3.7'

services:

  nginx-proxy-manager:
    image: jlesage/nginx-proxy-manager:latest
    container_name: nginx-proxy-manager
    restart: always
    expose:
      - 8181
    ports:
      - 80:8080
      - 443:4443
      - 8181:8181
    environment:
      TZ: Asia/Shanghai
    volumes:
      - ./volumes/nginx-proxy-manager:/config:rw
      - /var/run/docker.sock:/docker.sock:ro

networks:
  default:
    external:
      name: gateway
```

这里直接使用  `docker-compose up -d`  启动即可。

相关的配置及日志等，都会放在同级目录的vloumes中。

之后就可以使用宿主机地址加上8181访问nginx-manager，这里需要服务器安全策略先放开8181。

## 访问后台

访问后的界面是这样的:

![Screenshotfrom20210701103715.png](https://b3logfile.com/file/2021/07/Screenshot_from_2021-07-01_10-37-15-9fbdf49d.png)

这里是我之前已经配置过一些代理转发了。稍后我们先进行nginx本身的转发。

这里我们提前都要有自己已经备案过的域名，方便后续服务访问。

![Screenshotfrom20210701103908.png](https://b3logfile.com/file/2021/07/Screenshot_from_2021-07-01_10-39-08-8b9ae647.png)

填写好地址，比如nginx就是nginx.域名.后缀 ，这里根据自己的服务来设置，可以使用二级域名，也可以不。我一般都会使用二级域名，SSL使用泛域名证书，这样多个二级域名可以同配置同一个证书。

这里配置好nginx服务的转发后(8181)，我们修改docker-compose.yaml,将porst中的8181:8181去掉。这样我们宿主机就不会暴露任何端口到外部，除了80和443。到这里我们就可以把服务器的安全策略8181去除掉了。

修改好后，使用docker-compose up -d升级服务。

## 服务部署

因为我们的目的是使用nginx的同时，不向外部暴露任何宿主机端口。这样我们完全可以使用docker的局部网络networks。即我们的任何服务都启动在nginx同一网桥内，且expose:端口 配置好。这样nginx可以直接走docker内部网桥代理过去。

## SSL配置

![Screenshotfrom20210701104407.png](https://b3logfile.com/file/2021/07/Screenshot_from_2021-07-01_10-44-07-5e8fab00.png)

传统的nginx配置，都是需要上传到nginx所在服务器，手动更新配置，这里我们推荐使用泛域名证书，那样的话我不管我们使用的是什么二级域名，都可以通过一个SSL证书进行加密。

因为我的服务器在腾讯云，所以泛域名证书自动更新这里，我使用的是腾讯云的DNSPod服务，这里的配置即可让nginx-proxy-manager自动更新SSL证书，不需要我们自己去申请。

## 访问

![Screenshotfrom20210701104601.png](https://b3logfile.com/file/2021/07/Screenshot_from_2021-07-01_10-46-01-b5b2b3dc.png)

配置好后就可以直接使用二级域名进行访问了
