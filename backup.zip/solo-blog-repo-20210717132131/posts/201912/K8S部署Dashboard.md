title: K8S部署Dashboard
date: '2019-12-19 15:58:09'
updated: '2019-12-20 15:56:17'
tags: [K8S, Docker]
permalink: /articles/2019/12/19/1576742289921.html
---
![](https://img.hacpai.com/bing/20190201.jpg?imageView2/1/w/960/h/540/interlace/1/q/100) 

## K8S-Dashboard
生产环境部署了K8S集群免不了需要监控每个pod的状态，每个service的状态，乱七八糟的状态，官方的Dashboard就可以来干这件事～～～
### 环境准备
<hr>
目前的环境就是docker，k8s乱七八糟的都准备了。因为我部署的是v1.17.0版本的k8s，官方暂时还没说稳定支持的dashboard版本，用的是2.0.8的beta版。

### 部署服务
<hr>
因为我这里已经部署完了，好多镜像乱七八糟的还需要vpn拉啊什么的，我直接提供一份写好的yaml文件

```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: kubernetes-dashboard

---

apiVersion: v1
kind: ServiceAccount
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard
  namespace: kubernetes-dashboard

---

kind: Service
apiVersion: v1
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard
  namespace: kubernetes-dashboard
spec:
  type: NodePort
  ports:
    - port: 443
      targetPort: 8443
      nodePort: 30888
  selector:
    k8s-app: kubernetes-dashboard

---

apiVersion: v1
kind: Secret
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard-certs
  namespace: kubernetes-dashboard
type: Opaque

---

apiVersion: v1
kind: Secret
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard-csrf
  namespace: kubernetes-dashboard
type: Opaque
data:
  csrf: ""

---

apiVersion: v1
kind: Secret
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard-key-holder
  namespace: kubernetes-dashboard
type: Opaque

---

kind: ConfigMap
apiVersion: v1
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard-settings
  namespace: kubernetes-dashboard

---

kind: Role
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard
  namespace: kubernetes-dashboard
rules:
  # Allow Dashboard to get, update and delete Dashboard exclusive secrets.
  - apiGroups: [""]
    resources: ["secrets"]
    resourceNames: ["kubernetes-dashboard-key-holder", "kubernetes-dashboard-certs", "kubernetes-dashboard-csrf"]
    verbs: ["get", "update", "delete"]
    # Allow Dashboard to get and update 'kubernetes-dashboard-settings' config map.
  - apiGroups: [""]
    resources: ["configmaps"]
    resourceNames: ["kubernetes-dashboard-settings"]
    verbs: ["get", "update"]
    # Allow Dashboard to get metrics.
  - apiGroups: [""]
    resources: ["services"]
    resourceNames: ["heapster", "dashboard-metrics-scraper"]
    verbs: ["proxy"]
  - apiGroups: [""]
    resources: ["services/proxy"]
    resourceNames: ["heapster", "http:heapster:", "https:heapster:", "dashboard-metrics-scraper", "http:dashboard-metrics-scraper"]
    verbs: ["get"]

---

kind: ClusterRole
apiVersion: rbac.authorization.k8s.io/v1
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard
rules:
  # Allow Metrics Scraper to get metrics from the Metrics server
  - apiGroups: ["metrics.k8s.io"]
    resources: ["pods", "nodes"]
    verbs: ["get", "list", "watch"]

---

apiVersion: rbac.authorization.k8s.io/v1
kind: RoleBinding
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard
  namespace: kubernetes-dashboard
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: Role
  name: kubernetes-dashboard
subjects:
  - kind: ServiceAccount
    name: kubernetes-dashboard
    namespace: kubernetes-dashboard

---

apiVersion: rbac.authorization.k8s.io/v1
kind: ClusterRoleBinding
metadata:
  name: kubernetes-dashboard
roleRef:
  apiGroup: rbac.authorization.k8s.io
  kind: ClusterRole
  name: kubernetes-dashboard
subjects:
  - kind: ServiceAccount
    name: kubernetes-dashboard
    namespace: kubernetes-dashboard

---

kind: Deployment
apiVersion: apps/v1
metadata:
  labels:
    k8s-app: kubernetes-dashboard
  name: kubernetes-dashboard
  namespace: kubernetes-dashboard
spec:
  replicas: 1
  revisionHistoryLimit: 10
  selector:
    matchLabels:
      k8s-app: kubernetes-dashboard
  template:
    metadata:
      labels:
        k8s-app: kubernetes-dashboard
    spec:
      containers:
        - name: kubernetes-dashboard
          image: kubernetesui/dashboard:v2.0.0-beta8
          imagePullPolicy: Always
          ports:
            - containerPort: 8443
              protocol: TCP
          args:
            - --auto-generate-certificates
            - --namespace=kubernetes-dashboard
            # Uncomment the following line to manually specify Kubernetes API server Host
            # If not specified, Dashboard will attempt to auto discover the API server and connect
            # to it. Uncomment only if the default does not work.
            # - --apiserver-host=http://my-address:port
          volumeMounts:
            - name: kubernetes-dashboard-certs
              mountPath: /certs
              # Create on-disk volume to store exec logs
            - mountPath: /tmp
              name: tmp-volume
          livenessProbe:
            httpGet:
              scheme: HTTPS
              path: /
              port: 8443
            initialDelaySeconds: 30
            timeoutSeconds: 30
          securityContext:
            allowPrivilegeEscalation: false
            readOnlyRootFilesystem: true
            runAsUser: 1001
            runAsGroup: 2001
      volumes:
        - name: kubernetes-dashboard-certs
          secret:
            secretName: kubernetes-dashboard-certs
        - name: tmp-volume
          emptyDir: {}
      serviceAccountName: kubernetes-dashboard
      nodeSelector:
        "beta.kubernetes.io/os": linux
      # Comment the following tolerations if Dashboard must not be deployed on master
      tolerations:
        - key: node-role.kubernetes.io/master
          effect: NoSchedule

---

kind: Service
apiVersion: v1
metadata:
  labels:
    k8s-app: dashboard-metrics-scraper
  name: dashboard-metrics-scraper
  namespace: kubernetes-dashboard
spec:
  ports:
    - port: 8000
      targetPort: 8000
  selector:
    k8s-app: dashboard-metrics-scraper

---

kind: Deployment
apiVersion: apps/v1
metadata:
  labels:
    k8s-app: dashboard-metrics-scraper
  name: dashboard-metrics-scraper
  namespace: kubernetes-dashboard
spec:
  replicas: 1
  revisionHistoryLimit: 10
  selector:
    matchLabels:
      k8s-app: dashboard-metrics-scraper
  template:
    metadata:
      labels:
        k8s-app: dashboard-metrics-scraper
      annotations:
        seccomp.security.alpha.kubernetes.io/pod: 'runtime/default'
    spec:
      containers:
        - name: dashboard-metrics-scraper
          image: kubernetesui/metrics-scraper:v1.0.1
          ports:
            - containerPort: 8000
              protocol: TCP
          livenessProbe:
            httpGet:
              scheme: HTTP
              path: /
              port: 8000
            initialDelaySeconds: 30
            timeoutSeconds: 30
          volumeMounts:
          - mountPath: /tmp
            name: tmp-volume
          securityContext:
            allowPrivilegeEscalation: false
            readOnlyRootFilesystem: true
            runAsUser: 1001
            runAsGroup: 2001
      serviceAccountName: kubernetes-dashboard
      nodeSelector:
        "beta.kubernetes.io/os": linux
      # Comment the following tolerations if Dashboard must not be deployed on master
      tolerations:
        - key: node-role.kubernetes.io/master
          effect: NoSchedule
      volumes:
        - name: tmp-volume
          emptyDir: {}
```
这里我将dashboard的服务映射到本机的30888端口
复制以上yaml文本，创建好dashboard.yaml文件后，直接运行
```shell
kubectl apply -f dashboard.yaml
```
运行成功后，有如下提示
```
namespace/kubernetes-dashboard created
serviceaccount/kubernetes-dashboard created
service/kubernetes-dashboard created
secret/kubernetes-dashboard-certs created
secret/kubernetes-dashboard-csrf created
secret/kubernetes-dashboard-key-holder created
configmap/kubernetes-dashboard-settings created
role.rbac.authorization.k8s.io/kubernetes-dashboard created
clusterrole.rbac.authorization.k8s.io/kubernetes-dashboard created
rolebinding.rbac.authorization.k8s.io/kubernetes-dashboard created
clusterrolebinding.rbac.authorization.k8s.io/kubernetes-dashboard created
deployment.apps/kubernetes-dashboard created
service/dashboard-metrics-scraper created
deployment.apps/dashboard-metrics-scraper created

```
这时，dashboard的pods和service都已经在创建过程中了，yaml中用的默认命名，命名空间是kubernetes-dashboard
执行
```
kubectl get pods -n kubernetes-dashboard
```
查看运行状态，如果状态如下
```
NAME                                         READY     STATUS    RESTARTS   AGE
dashboard-metrics-scraper-76585494d8-blgzp   1/1       Running   0          48m
kubernetes-dashboard-5996555fd8-zzcd7        1/1       Running   0          48m
```
说明部署成功。
### 访问服务
<hr>
部署成功后，我们需要访问dashboard进行验证，我们需要先去命名空间下的服务中查看端口映射状态。

```
kubectl get service -n kubernetes-dashboard
```
服务状态如下：
```
NAME                        TYPE        CLUSTER-IP      EXTERNAL-IP   PORT(S)         AGE
dashboard-metrics-scraper   ClusterIP   10.96.135.114   <none>        8000/TCP        51m
kubernetes-dashboard        NodePort    10.96.83.229    <none>        443:30888/TCP   51m

```
这里可以看到30888端口的映射已经成功了，这里我们有两种方式访问dashboard。
第一种  根据本地IP和映射端口访问
```
https://本地IP:30888
```
是https的，因为k8s本身的防止中间人攻击的机制，这里不多说了。
第二种 用clusterip
```
https://10.96.83.229:443
```
用本身分配的cluster-IP进行访问
访问成功页面如下
![Screenshotfrom20191219153951.png](https://img.hacpai.com/file/2019/12/Screenshotfrom20191219153951-0ca57dfa.png)

### 权限控制
<hr>
如上图所示，dashboard提供了两种访问形式，一种用集群配置上传，一种是提供token。
一般在使用的时候，都是用token的形式，这样既可以省事，也能区分出来每个不同权限人可以访问的明明空间。
我们这里因为是需要进行集群管理，所以需要配置cluster-admin的权限。否则相应的数据我们是拿不到的，具体配置方式如下。

#### 创建账户

```
kubectl create serviceaccount -n kube-system super
```
这里我们创建一个super用户

#### 绑定角色

```
kubectl get clusterrole -n kube-system
```
我们需要检查一下是否有role或者clusterrole的绑定，因为这里测试没那么高的安全要求，这里给super用户最高权限。

```
kubectl create clusterrolebinding super-cluster-admin --clusterrole=cluster-admin --serviceaccount=kube-system:super
```
#### 获取Token
到这里我们的账户已经拥有了集群管理权限了，接下来我们需要去获取Token用于登录dashboard。
先检查一下账户是否存在
```
kubectl describe scerviceAccount super -n kube-system
```
存在的话会携带一个token入口，我们需要那这token入口去获取token。
具体如下
```
Name:                super
Namespace:           kube-system
Labels:              <none>
Annotations:         <none>
Image pull secrets:  <none>
Mountable secrets:   super-token-fwl76
Tokens:              super-token-fwl76
Events:              <none>

```
我们那这Tokens对应的值去获取token：
```
kubectl describe secret super-token-fwl76 -n kube-system
```
拿到的token情况如下：
```
Name:         super-token-fwl76
Namespace:    kube-system
Labels:       <none>
Annotations:  kubernetes.io/service-account.name=super
              kubernetes.io/service-account.uid=5789fdca-e470-455b-891c-2f479a8a6b48

Type:  kubernetes.io/service-account-token

Data
====
token:      eyJhbGciOiJSUzI1NiIsImtpZCI6InVyRmFoTlhLWjcxT19MSERsSHlBa3B1WHg0bFloUEV6TjgzU0ZaNE5ySjAifQ.eyJpc3MiOiJrdWJlcm5ldGVzL3NlcnZpY2VhY2NvdW50Iiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9uYW1lc3BhY2UiOiJrdWJlLXN5c3RlbSIsImt1YmVybmV0ZXMuaW8vc2VydmljZWFjY291bnQvc2VjcmV0Lm5hbWUiOiJ0aWxsZXItdG9rZW4tZndsNzYiLCJrdWJlcm5ldGVzLmlvL3NlcnZpY2VhY2NvdW50L3NlcnZpY2UtYWNjb3VudC5uYW1lIjoidGlsbGVyIiwia3ViZXJuZXRlcy5pby9zZXJ2aWNlYWNjb3VudC9zZXJ2aWNlLWFjY291bnQudWlkIjoiNTc4OWZkY2EtZTQ3MC00NTViLTg5MWMtMmY0NzlhOGE2YjQ4Iiwic3ViIjoic3lzdGVtOnNlcnZpY2VhY2NvdW50Omt1YmUtc3lzdGVtOnRpbGxlciJ9.q6X1nkIiberHiGtBxzNdFyebsPlKWGwMEUK4n_wm5kFREntUbVD1kC3FkChfSfNgy0Qinvx-zGvobrXPXzb3XWXfwEFwkBHK_098iikxNgIMIGoPVJI2ZbC_aAdLvh1sDFAiJE4cYuxsUjYLwHzy5RcfnjeKfoqItCrh5c0txYFT-Paivd9JCDUttnk6Rxoqoyb4ElTpDoYUm2k31BLWdVuL4TuMpvULCtBdEdr92Z5cJraHHRaUbfn-80--Rc0z64baKPQXYXWrJwRMDY3nmpYJ0KfNyBk-IbAIFfIYTlTqIpImcFSKB2Gc5MexDWVTzwlebHy5KM8RWLvy8oyshg
ca.crt:     1025 bytes
namespace:  11 bytes

```
其中token的值就是我们需要的。
### 登录查看
<hr>
现在我们拿到了需要的token值，可以复制到登录页面登陆了
登陆成功后效果如下

![Screenshotfrom20191219155626.png](https://img.hacpai.com/file/2019/12/Screenshotfrom20191219155626-7c476bf2.png)

这里我已经运行了测试的pods了，具体功能大家自己看吧哈哈。。～～～结束

### FAQ
个别的拿不到数据，提示forbidden的可能是版本对不上，或者权限没给好。over
