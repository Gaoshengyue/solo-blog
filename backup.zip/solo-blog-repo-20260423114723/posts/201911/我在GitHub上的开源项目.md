title: 我在 GitHub 上的开源项目
date: '2019-11-16 17:14:58'
updated: '2019-11-16 17:14:58'
tags: [GitHub, 开源]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [public-blog](https://github.com/Gaoshengyue/public-blog) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/Gaoshengyue/public-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`1`](https://github.com/Gaoshengyue/public-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Gaoshengyue/public-blog/network/members "分叉数")</span>





---

### 2. [switchdjango](https://github.com/Gaoshengyue/switchdjango) <kbd title="主要编程语言">Python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Gaoshengyue/switchdjango/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Gaoshengyue/switchdjango/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Gaoshengyue/switchdjango/network/members "分叉数")</span>





---

### 3. [myblog](https://github.com/Gaoshengyue/myblog) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Gaoshengyue/myblog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Gaoshengyue/myblog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Gaoshengyue/myblog/network/members "分叉数")</span>





---

### 4. [room](https://github.com/Gaoshengyue/room) <kbd title="主要编程语言">HTML</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Gaoshengyue/room/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Gaoshengyue/room/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Gaoshengyue/room/network/members "分叉数")</span>





---

### 5. [webchat](https://github.com/Gaoshengyue/webchat) <kbd title="主要编程语言">CSS</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Gaoshengyue/webchat/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Gaoshengyue/webchat/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Gaoshengyue/webchat/network/members "分叉数")</span>


---

### 6. [Semantic_cs](https://github.com/Gaoshengyue/Semantic_cs)<kbd title="主要编程语言">python</kbd> <span style="font-size: 12px;">[🤩`0`](https://github.com/Gaoshengyue/Semantic_cs/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/Gaoshengyue/Semantic_cs/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/Gaoshengyue/Semantic_cs/network/members "分叉数")</span>