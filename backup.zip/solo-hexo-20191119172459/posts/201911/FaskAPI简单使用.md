title: FaskAPI简单使用
date: '2019-11-18 14:51:25'
updated: '2019-11-18 18:50:50'
tags: [FastApi]
permalink: /articles/2019/11/18/1574059884992.html
---
## <center>FastApi(简介篇)</center>
### 开篇
最近又抽空看了看开源的框架，由于近一年python使用的比较多，所以关注了一下python的web框架情况，其中一款官方称其为“One of the fastest Python frameworks available”的框架比较引人注目，刚看的时候并不是被性能方面的介绍吸引，而是他的集成docs，以下先来看一下框架自动生成的效果。
![index01swaggeruisimple.png](https://img.hacpai.com/file/2019/11/index01swaggeruisimple-aadad1a4.png)
文档页面，集测试、文档功能于一体，还是比较好用的，哈哈。
趁热打铁再来看一下性能方面
![Screenshotfrom20191118155254.png](https://img.hacpai.com/file/2019/11/Screenshotfrom20191118155254-876348af.png)
**fastapi稳居第一**
看一下以往用的非常多的flask、django等都排在了后面。
### FastApi简介
总结来说，就是快、好用、好看
### 快速启动FastApi应用

因为官方对python3.6表现出了很好的亲和力，那么我们在这也会使用python3.6进行构建。
因为我本人用的是Ubuntu18的系统，以下关于应用安装部分，以linux为准。
```
sudo apt-get install python3
```
这里关于python3的安装就不再赘述了，windows直接下载相关安装包即可。
接下来开始安装FastApi的库
```
pip3 install fastapi -i https://pypi.doubanio.com/simple
```
因为大家都知道的网络问题，这里使用豆瓣源进行安装
```
pip3 install uvicorn -i https://pypi.doubanio.com/simple
```
这里安装的uvicorn是一个轻量级高效的web服务器框架，这里就不再陈述了，往后有机会会着重介绍。
安装后了相关库之后，需要创建py文件用来做我们的启动app
```
vim main.py
```
``main.py``内编辑如下内容:
```python
from fastapi import FastAPI
my_app = FastAPI()

@app.get("/")
def read_index():
      return {"Hello":"World"}
```
就此，可以启动一个简单的FastAPI项目了，结构上类似flask
```
uvicorn main:my_app --reload
```
启动后访问``http://127.0.0.1``就可以看到我们返回的json数据了
访问``http://127.0.0.1/docs``即可查看和测试api


