title: 接触企业级框架SpringBoot(一)
date: '2020-03-13 17:52:37'
updated: '2020-03-13 17:52:37'
tags: [java, springboot]
permalink: /articles/2020/03/13/1584093157241.html
---
![](https://img.hacpai.com/bing/20181122.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 概述
作为大程序猿子，相信没有人不知道Java，用过Java的人，应该也很少有人没有接触过SpringBoot，作为目前最为出名，且应用最为广泛的企业级应用框架，SpringBoot不管是使用的广泛性、可用性、实用性多个方面，都具有非常良好的验证。本篇开始，就SpringBoot框架进行初步的学习，大家自取所需。
## 环境
### jdk
安装java的jdk,目前用的普遍1.8
[https://www.oracle.com/java/technologies/javase-jdk8-downloads.html](https://)
### IDE
IDE直接使用jetbrains全家桶吧，目前也比较流行好用了
[https://www.jetbrains.com/idea/download/#section=linux](https://)

## 项目结构
### 整体树结构
```
├── demo.iml
├── HELP.md
├── pom.xml
├── src
│   ├── main
│   │   ├── java
│   │   │   └── com
│   │   │       └── example
│   │   │           └── demo
│   │   │               ├── model
│   │   │               │   └── User.java
│   │   │               ├── modelRegistry
│   │   │               │   └── UserRegistry.java
│   │   │               ├── status
│   │   │               │   └── ResultStatus.java
│   │   │               ├── TestSpringdemo.java
│   │   │               └── user
│   │   │                   └── UserAdmin.java
│   │   └── resources
│   │       ├── application.yml
│   │       ├── static
│   │       └── templates
│   │           └── index.html
│   └── test
│       └── java
│           └── com
│               └── example
│                   └── demo

```
因为项目建的比较随意，没有好好整理文件目录，本篇先就这个讲吧。

### 项目包管理

以此demo为例，包管理使用maven平台，配置文件为pox.xml
```
<?xml version="1.0" encoding="UTF-8"?>
<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
         xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 https://maven.apache.org/xsd/maven-4.0.0.xsd">
    <modelVersion>4.0.0</modelVersion>
    <parent>
        <groupId>org.springframework.boot</groupId>
        <artifactId>spring-boot-starter-parent</artifactId>
        <version>2.2.5.RELEASE</version>
        <relativePath/> <!-- lookup parent from repository -->
    </parent>
    <groupId>com.example</groupId>
    <artifactId>demo</artifactId>
    <version>0.0.1-SNAPSHOT</version>
    <name>demo</name>
    <description>Demo project for Spring Boot</description>

    <properties>
        <java.version>1.8</java.version>
    </properties>

    <dependencies>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-web</artifactId>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-thymeleaf</artifactId>
        </dependency>
        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-freemarker</artifactId>
        </dependency>
        <dependency>
            <groupId>mysql</groupId>
            <artifactId>mysql-connector-java</artifactId>
            <version>5.0.4</version>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-data-jpa</artifactId>
        </dependency>

        <dependency>
            <groupId>org.projectlombok</groupId>
            <artifactId>lombok</artifactId>
<!--            <version>1.18.12</version>-->
            <scope>provided</scope>
        </dependency>

        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>druid</artifactId>
            <version>1.1.0</version>
        </dependency>

        <!-- https://mvnrepository.com/artifact/com.alibaba/fastjson -->
        <dependency>
            <groupId>com.alibaba</groupId>
            <artifactId>fastjson</artifactId>
            <version>1.2.66</version>
        </dependency>

        <dependency>
            <groupId>org.springframework.boot</groupId>
            <artifactId>spring-boot-starter-test</artifactId>
            <scope>test</scope>
            <exclusions>
                <exclusion>
                    <groupId>org.junit.vintage</groupId>
                    <artifactId>junit-vintage-engine</artifactId>
                </exclusion>
            </exclusions>
        </dependency>
    </dependencies>





    <build>
        <plugins>
            <plugin>
                <groupId>org.springframework.boot</groupId>
                <artifactId>spring-boot-maven-plugin</artifactId>
            </plugin>
        </plugins>
    </build>

</project>

```
这里使用了springframework的一些包，阿里的fastjson包，mysql连接包，还有很多包就不列举了。

### 配置项

配置项在application.yml

```
server:
  port: 8088
spring:
  datasource:
    driver-class-name: org.gjt.mm.mysql.Driver
    type: com.alibaba.druid.pool.DruidDataSource
    url: jdbc:mysql://localhost:3306/test?useUnicode=true&characterEncoding=utf8
    username: root
    password: root
    dbcp2:
      min-idle: 5
      initial-size: 5
      max-total: 5
      max-wait-millis: 1000

  jpa:
    database: mysql
    show-sql: true #后台显示sql语句

    hibernate:
      ddl-auto: update
  freemarker:
    template-loader-path: classpath:/templates/
    suffix: .html
    allow-request-override: false
    cache: true
    check-template-location: true
    charset: UTF-8
    content-type: text/html
    expose-request-attributes: false
    expose-session-attributes: false
    expose-spring-macro-helpers: false
```
这里包括了mysql配置项，启动端口，模板配置等

### 目录作用

resource目录中管理资源，static为静态文件目录，templates为模板目录

### 项目启动类
TestSpringdemo.java为项目整理入口，项目启动从此类开始，代码如下
```
package com.example.demo;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
//@RestController
@SpringBootApplication
public class TestSpringdemo {
    @RequestMapping(value = "/hello")
    public String greeting(){

        return "hello word";
    }

    @RequestMapping(value = "/hello",method = RequestMethod.POST)
    public String second(){


        return "Here,POST";
    }

    @RequestMapping("/")
    public String index(ModelMap map){
        map.addAttribute("newt","symoon");
        return "index";
    }


    public static void main(String [] args){

        SpringApplication.run(TestSpringdemo.class,args);
    }
}

```
这里定义TestSpringdemo为启动类，定义了两个跳转路由。`/hello`和`/`
这里的主要定义方式为注解形式，即`@Controller`等注解，注解详细功能参照spring官方文档。
这里如果使用`@RestController`即使用Rest风格控制器，无法使用模板，因为这里使用`freemarker`的模板渲染，所以使用`@Controller`注解。
这里除了区分POST和GET请求外，还添加了模板渲染示例。
```
@RequestMapping("/")  
public String index(ModelMap map){ 
map.addAttribute("newt","symoon"); 
return  "index"; 
}
```
此代码中定义模板变量`newt`,传参`symoon`,`return`会`index`模板
index.html代码如下
```
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
<h1>${newt}</h1>
</body>
</html>
```
与其他框架的渲染引擎稍有不同。
这里注意，我们在配置项中`suffix`定义了识别html文件，所以其他文件无法识别为模板，默认为`ftl`文件。
### 定义Model
Model的定义即数据库表结构对应，根据我们需要的业务表结构定义即可，｀model/User.java｀
```
package com.example.demo.model;
import javax.persistence.*;
import lombok.Data;
import org.springframework.data.jpa.repository.JpaRepository;

@Data
@Entity
@Table(name="user")
public class User {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)  
    private  int id;
    @Column(name="username")
    private String username;

    @Column(name = "password")
    private String password;

    public void setUsername(String username){
        this.username=username;
    }
    public void setPassword(String password){

        this.password=password;
    }
    public Integer getId(){

        return id;
    }
    public String getUsername(){
        return username;
    }
    public String getPassword(){
        return password;
    }

}
```
这里使用了`lombok`，`javax`两个库，定义最简单的一个表结构，为了方便插入数据的例子，定义`setUsername`和`setPassword`两个方法。
### 映射关系集成
使用此Model与数据库做映射，需要对应创建`Repository`,`modelRegistry/UserRegistry.java`
```
package com.example.demo.modelRegistry;
import com.example.demo.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRegistry extends JpaRepository<User,Integer> {


}
```
### 表操作测试

这里举两个操作例子，查和插入，改和删也比较简单，这里先不举例了,`user/UserAdmin.java`

```
package com.example.demo.user;


import com.alibaba.fastjson.JSONObject;
import com.example.demo.model.User;
import com.example.demo.modelRegistry.UserRegistry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;



@RestController
@ResponseBody
@RequestMapping("/user")
public class UserAdmin {
    @Autowired
    private UserRegistry respository;

    @RequestMapping(value = "/admin",method = RequestMethod.GET)
    public List<User> dataList(){

        return respository.findAll();
    }


    @RequestMapping(value = "/admin",method = RequestMethod.POST)
    public User InsertUser(@RequestBody JSONObject jsonObject){
        System.out.println(jsonObject.toJSONString());
        User userObj=new User();
        userObj.setUsername(jsonObject.get("username").toString());
        userObj.setPassword(jsonObject.get("password").toString());

        return respository.save(userObj);
    }
}

```

查询这里我们应用定义好的User类，查询出所有用户数据对象数组后定义好返回type直接返回。
插入这里我们使用`@RequestBody`注解，使用阿里的fastjson来解析json参数。
调用我们之前定义好的`setUsername`和`setPassword`方法，将解析来的数据直接传递到实例化好的对象中，save方法提交插入的对象，返回插入的结果。