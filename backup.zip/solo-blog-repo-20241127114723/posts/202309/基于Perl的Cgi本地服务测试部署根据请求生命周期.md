title: 基于Perl的Cgi本地服务测试部署(根据请求生命周期)
date: '2023-09-13 18:05:32'
updated: '2023-09-13 18:05:32'
tags: [perl, cgi]
permalink: /articles/2023/09/13/1694599532453.html
---
![](https://b3logfile.com/bing/20180720.jpg?imageView2/1/w/960/h/540/interlace/1/q/100)

## 工程目录

```
D:.
├─cgi-bin
├─lib
```

Cgi服务的部署需要依赖于apache httpd，本文使用docker模拟服务器部署cgi脚本服务的过程。

## 服务部署流程

首先工程目录如上所示，cgi-bin用来放置cgi脚本。例如在cgi-bin里面创建index.cgi文件(cgi可以用perl也可以用其他语言编写),示例代码如下:

```perl
#!/usr/bin/perl
use strict;
use warnings FATAL => 'all';
use lib;
use Test qw(testReturn);

print "Content-type: text/html\n\n";
my $result_num = testReturn(3);
print "<h1>$result_num</h1>";
```

上面调用了lib里面的perl的处理逻辑脚本pm文件里面的函数。返回了一个数字并且嵌入到html返回给请求方。

脚本文件Test.pm，代码如下

```perl
package Test;
use strict;
use warnings FATAL => 'all';
my @EXPORT = qw(testReturn);
use Exporter qw(import);
our @EXPORT_OK = @EXPORT;
sub testReturn {
    my ($test_num) = @_;
    $test_num = $test_num+1;
    return $test_num
}

1;
```

其中设置了导出的函数，将调用函数的数字+1。

通过这两个代码，http请求被接收后会返回4；

Cgi脚本需要有httpd服务进行解析，接下来我们开始配置整个的服务编排。

创建Dockerfile文件。

```yaml
# 使用官方的 Perl 镜像作为基础镜像
FROM perl:latest

# 安装 Apache HTTP Server 和 CGI 模块
RUN apt-get update && apt-get install -y apache2 libapache2-mod-perl2

# 将项目文件复制到容器中
COPY . /var/www/html/

# 配置 Apache
RUN chmod +x /var/www/html/cgi-bin/index.cgi
COPY httpd.conf /etc/apache2/sites-available/000-default.conf
RUN a2enmod cgi


# 暴露端口
EXPOSE 80

# 启动 Apache
CMD ["apachectl", "-D", "FOREGROUND"]

```

这个Dockerfile文件引用了perl的官方基础镜像，安装了apache httpd的包，并且复制项目文件到容器中，配置了apache的conf，由本地conf文件复制到容器中，赋予脚本呢执行权限后执行服务启动命令，并暴露80端口。

本地的httpd配置如下(httpd.conf):

```
<VirtualHost *:80>
    DocumentRoot /var/www/html
    Alias /cgi-bin/ /var/www/html/cgi-bin/
    <Directory "/var/www/html/cgi-bin/">
        Options +ExecCGI
        AddHandler cgi-script .cgi .pl  # 添加 .pl 扩展名
    </Directory>

</VirtualHost>
```

这个配置里面配置了监听80端口，目录 `/var/ww/html`，转发了 `/cgi-bin/`到 `/var/www/html/cgi-bin/`目录，也就是cgi脚本所在目录。同时设置 `Options +ExeCGI`的cgi解析模式，添加扩展名 `.cgi`和 `.pl`(perl脚本文件)。

整个的流程服务就是复制项目文件到容器中，同时启动apache httpd服务，根据配置将请求转发到cgi脚本上处理请求。

## 启动指令

```
docker build -t my-perl-cgi-app .
```

构建完成后

```
docker run -p 80:80 my-perl-cgi-app
```

之后直接访问 `http://127.0.0.1`

显示

![image.png](https://b3logfile.com/file/2023/09/image-HFaiOmn.png)

说明服务启动成功。查看对应路由是否返回cgi脚本执行的逻辑结果。

![image.png](https://b3logfile.com/file/2023/09/image-kX03cAn.png)

再创建一个test.cgi脚本放入/cgi-bin目录。写入

```perl
#!/usr/bin/perl
use strict;
use warnings;
print "Content-type: text/html\n\n";
print "44";
```

返回 `44`，请求 `http://127.0.0.1/cgi-bin/test.cig`返回44。到此服务启动完毕。
