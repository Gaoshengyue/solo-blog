title: K8S部署Mysql(NFS持久化)
date: '2020-01-19 14:27:57'
updated: '2020-01-19 14:27:57'
tags: [K8S]
permalink: /articles/2020/01/19/1579415277373.html
---
## K8S
Kubernetes就不多说了，之前也说过很多次了，作为目前大家都在谈论的东西，肯定是极好的。接下来直接上正文部署吧，接下来的几篇部署文档都很简单，直接上配置。
## Mysql部署
部署Mysql的前提是有K8s集群，之前有一篇已经详细写过如何测试部署K8s集群了，这里就不再多说。
### NFS服务创建
这里不说了，大家可以自行搜索一下创建NFS存储服务，这里依赖的持久化就是NFS服务。
### Mysql PV/PVC创建

Persistent Volume和Persistent Volume Claim，主要是管理服务持久化的存储资源Volume。这里我们先创建PV，再创建PVC，将两者绑定。
首先是mysql-pv.yaml
```yaml
kind: PersistentVolume
apiVersion: v1
metadata:
  name: mysql-pv
  namespace: database
spec:
  accessModes:
    - ReadWriteOnce      
  capacity:
    storage: 1Gi
  persistentVolumeReclaimPolicy: Retain
  storageClassName: nfs
  nfs:
    path: /data/nfs/mysql
    server: nfs服务IP
```
配置中包含命名空间，模式ReadWriteOnce,资源分配,名称对应，nfs路径等等等。。
执行
```
kubectl apply -f mysql-pv.yaml
```
接下来是mysql-pvc.yaml
```yaml
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: mysql-pvc
  namespace: database
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 1Gi
  storageClassName: nfs     
```
这里其他配置与PV保持一致，同一命名空间database下，同一个storageClassName
执行
```
kubectl apply -f mysql-pvc.yaml
```
创建好后我们来看一下状态。
```
kubectl get pv -n database
```
正常的PV状态如下
```
NAME                                       CAPACITY   ACCESS MODES   RECLAIM POLICY   STATUS   CLAIM                                                               STORAGECLASS                   REASON   AGE
mysql-pv                                   1Gi        RWO            Retain           Bound    database/mysql-pvc                                                  nfs                                     4d3h

```
STATUS是BOUND状态
接下来看一下pvc
```
kubectl get pvc -n database
```
正常状态如下
```
NAME                                                       STATUS   VOLUME                CAPACITY   ACCESS MODES   STORAGECLASS                   AGE
mysql-pvc                                                  Bound    mysql-pv              1Gi        RWO            nfs                            4d3h
```
STATUS依旧是BOUND，我们的PV/PVC持久化搭建完毕
### Mysql Deploy创建

这里是我们服务的本体，关于Deploy就不多说了
这里我们创建mysql-deploy.yaml
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: mysql
  namespace: database
spec:
  selector:
    matchLabels:
      app: mysql
  template:
    metadata:
      labels:
        app: mysql
    spec:
      containers:
      - name: mysql
        image: mysql:5.7
        env:                        
        - name: MYSQL_ROOT_PASSWORD
          value: "password"
        ports:
        - containerPort: 3306
        volumeMounts:
        - name: mysql-persistent-storage
          mountPath: /var/lib/mysql         
      volumes:
      - name: mysql-persistent-storage
        persistentVolumeClaim:
          claimName: mysql-pvc      
```
这里我们配置的是mysql服务相关信息，包括镜像的拉取，内部存储的映射。没有什么大问题等待服务部署成功就好了。
```
kubectl apply -f mysql-deploy.yaml
```
### Mysql Service创建
Deploy部署我们服务的本体，接下来创建访问服务的通道。
创建mysql-service.yaml
```yaml
apiVersion: v1
kind: Service
metadata:
  name: mysql
  namespace: database
spec:
  type: NodePort
  ports:
  - port: 3306
    targetPort: 3306
    nodePort: 31111
  selector:
    app: mysql
  selector:
    app: mysql
```
这里我选择NodePort类型，是因为用31111端口将服务暴露出来，不过用于我们同一个命名空间下的服务，可以直接通过服务名字进行访问。
```
kubectl apply -f mysql-service.yaml
```
可以根据我们的mysql所在Node＋31111的形式进行访问了。nfs服务器上已经创建了相关mysql持久化文件。